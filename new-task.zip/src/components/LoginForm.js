import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { login } from '../redux/userSlice'
import { useNavigate } from 'react-router-dom'

function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const handleLogin = (e) => {
    e.preventDefault()
    if (email && password) {
      dispatch(login({ email }))
      navigate('/products')
    }
  }

  return (
    <div className="container mt-5">
      <div className="card shadow p-4">
        <h3 className="mb-4">Login</h3>
        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="form-control"
              required
            />
          </div>
          <div className="mb-3">
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="form-control"
              required
            />
          </div>
          <button type="submit" className="btn btn-success w-100">Login</button>
        </form>
      </div>
    </div>
  )
}

export default LoginForm
