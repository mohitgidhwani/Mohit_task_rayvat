import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { setProducts, deleteProduct } from '../redux/productSlice'
import axios from 'axios'
import ProductForm from './ProductForm'

function ProductTable() {
  const dispatch = useDispatch()
  const products = useSelector(state => state.products)

  useEffect(() => {
    axios.get('https://dummyjson.com/products')
      .then(res => {
        dispatch(setProducts(res.data.products))
      })
  }, [dispatch])

  const handleDelete = (id) => {
    dispatch(deleteProduct(id))
  }

  return (
    <div className="container mt-5">
      <ProductForm />
      <table className="table table-bordered table-striped">
        <thead className="table-dark">
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Price ($)</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {products.map(prod => (
            <tr key={prod.id}>
              <td>{prod.id}</td>
              <td>{prod.title}</td>
              <td>{prod.price}</td>
              <td>
                <button onClick={() => handleDelete(prod.id)} className="btn btn-danger btn-sm">
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default ProductTable
