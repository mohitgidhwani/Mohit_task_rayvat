import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

function RegisterForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const navigate = useNavigate()

  const handleRegister = (e) => {
    e.preventDefault()
    if (email && password) {
      navigate('/login')
    }
  }

  return (
    <div className="container mt-5">
      <div className="card shadow p-4">
        <h3 className="mb-4">Register</h3>
        <form onSubmit={handleRegister}>
          <div className="mb-3">
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="form-control"
              required
            />
          </div>
          <div className="mb-3">
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="form-control"
              required
            />
          </div>
          <button type="submit" className="btn btn-primary w-100">Register</button>
        </form>
      </div>
    </div>
  )
}

export default RegisterForm
