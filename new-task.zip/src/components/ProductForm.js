import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addProduct } from '../redux/productSlice'

function ProductForm() {
  const [title, setTitle] = useState("")
  const [price, setPrice] = useState("")
  const dispatch = useDispatch()
  const products = useSelector(state => state.products)

  const handleAdd = (e) => {
    e.preventDefault()
    if (!title || !price) return

    const newProduct = {
      id: products.length + 1,
      title,
      price
    }

    dispatch(addProduct(newProduct))
    setTitle("")
    setPrice("")
  }

  return (
    <form onSubmit={handleAdd} className="mb-4">
      <h5 className="mb-3">Add Product</h5>
      <div className="mb-2">
        <input
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="form-control"
        />
      </div>
      <div className="mb-2">
        <input
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          className="form-control"
        />
      </div>
      <button type="submit" className="btn btn-primary">Add Product</button>
    </form>
  )
}

export default ProductForm
