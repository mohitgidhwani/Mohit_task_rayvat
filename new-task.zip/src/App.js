import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'

import LoginForm from './components/LoginForm'
import RegisterForm from './components/RegisterForm'
import ProductTable from './components/ProductTable'

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<RegisterForm />} />
          <Route path="/login" element={<LoginForm />} />
          <Route path="/products" element={<ProductTable />} />
        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App
